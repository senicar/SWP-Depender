=== Dummy plugin sample ===
Contributors: senicar
Tags: sample, dummy
Requires at least: 3.5
Tested up to: 3.9
Stable tag: 0.0.1

Short description

== Description ==

Long description

= Features =

* Feature 1
* Feature 2

== Installation ==

1. Upload `dummy-plugin-sample` folder to the `/wp-content/plugins/` directory

== Changelog ==

= 0.0.1 =
* Initial version
