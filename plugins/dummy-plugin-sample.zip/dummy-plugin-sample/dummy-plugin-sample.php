<?php
/*
Plugin Name: Dummy plugin sample
Description: This is a dummy plugin for testing
Plugin URL: http://github.com/senicar
Version: 0.0.1
Author: Senicar
Author URI: http://github.com/senicar
*/

if ( ! defined( 'ABSPATH' ) ) exit;
